import pandas as pd
df = pd.read_csv("data/processed/dataset.csv", dtype=str)
# replace scientific_name with family (or keep both)
df['label'] = df['family'].fillna('unknown')
df.to_csv("data/processed/dataset_family.csv", index=False)
print("Saved dataset_family.csv")
