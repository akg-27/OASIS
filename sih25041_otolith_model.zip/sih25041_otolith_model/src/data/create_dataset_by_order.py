import pandas as pd
import os

# Paths (adjust if needed)
CSV = "data/raw/indobis_otolith_full_details.csv"
IMG_DIR = "data/raw/Otolith_Images"
OUT = "data/processed/dataset.csv"

os.makedirs(os.path.dirname(OUT), exist_ok=True)

df = pd.read_csv(CSV, dtype=str)
imgs = sorted([f for f in os.listdir(IMG_DIR) if f.lower().endswith(('.jpg', '.jpeg', '.png'))])
if len(imgs) != len(df):
    print(f"Warning: #images={len(imgs)} != #rows={len(df)} -- continuing but check mapping")

rows = []
for i, (_, row) in enumerate(df.iterrows()):
    img = imgs[i] if i < len(imgs) else ""
    rows.append({
        "image": img,
        "otolithID": row.get('otolithID', ''),
        "scientific_name": row.get('scientific_name', ''),
        "family": row.get('family', ''),
        "detail_url": row.get('detail_url', ''),
        "locality": row.get('locality', '')
    })

out = pd.DataFrame(rows)
out.to_csv(OUT, index=False)
print("Wrote:", OUT, "with", len(out), "rows")
