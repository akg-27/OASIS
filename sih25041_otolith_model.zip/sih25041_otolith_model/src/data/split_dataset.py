import pandas as pd
from sklearn.model_selection import train_test_split
import os

IN = "data/processed/dataset.csv"
TRAIN = "data/processed/train.csv"
VAL = "data/processed/val.csv"
TEST = "data/processed/test.csv"

os.makedirs(os.path.dirname(TRAIN), exist_ok=True)

df = pd.read_csv(IN, dtype=str).fillna('unknown')
try:
    train, test = train_test_split(df, test_size=0.2, stratify=df['scientific_name'], random_state=42)
    train, val = train_test_split(train, test_size=0.1111, stratify=train['scientific_name'], random_state=42)
except Exception as e:
    print('Stratify failed:', e)
    train, test = train_test_split(df, test_size=0.2, random_state=42)
    train, val = train_test_split(train, test_size=0.1111, random_state=42)

train.to_csv(TRAIN, index=False)
val.to_csv(VAL, index=False)
test.to_csv(TEST, index=False)
print('Train/Val/Test sizes:', len(train), len(val), len(test))
