import pandas as pd
import os

IN = 'data/processed/dataset.csv'
OUT = 'data/reports/species_counts.csv'

df = pd.read_csv(IN, dtype=str)
print('Total samples:', len(df))
print('Unique species:', df['scientific_name'].nunique())
counts = df['scientific_name'].value_counts()
print(counts.head(20))

os.makedirs('data/reports', exist_ok=True)
counts.to_csv(OUT)
print('Saved species counts to', OUT)
