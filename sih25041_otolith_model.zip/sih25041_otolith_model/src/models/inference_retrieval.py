# inference_retrieval.py
import numpy as np, json, os, argparse
from PIL import Image
import torchvision.transforms as T
import timm, torch
from sklearn.metrics.pairwise import cosine_similarity

parser = argparse.ArgumentParser()
parser.add_argument('--query', required=True, help='path to query image')
parser.add_argument('--emb_file', default='data/processed/embeddings.npz')
parser.add_argument('--topk', type=int, default=5)
args = parser.parse_args()

data = np.load(args.emb_file, allow_pickle=True)
embs = data['embeddings']   # shape (N, D)
meta = data['meta']         # list of dicts

# load same backbone to embed query
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = timm.create_model("resnet50", pretrained=True)
model.reset_classifier(0)
model = model.to(device)
model.eval()

trans = T.Compose([T.Resize((224,224)), T.ToTensor()])

def embed_image(path):
    img = Image.open(path).convert('RGB')
    x = trans(img).unsqueeze(0).to(device)
    with torch.no_grad():
        feat = model.forward_features(x)
        feat = torch.nn.functional.adaptive_avg_pool2d(feat,1).squeeze().cpu().numpy()
        feat = feat / (np.linalg.norm(feat)+1e-10)
    return feat

q = embed_image(args.query)
# compute cosine similarities
sims = cosine_similarity(q.reshape(1,-1), embs).squeeze()  # shape (N,)
idx = sims.argsort()[::-1][:args.topk]

preds = []
for i in idx:
    m = meta[int(i)]
    preds.append({
        'image': m['image'],
        'scientific_name': m['scientific_name'],
        'family': m.get('family',''),
        'locality': m.get('locality',''),
        'detail_url': m.get('detail_url',''),
        'score': float(sims[int(i)])
    })

out = {'query_image': os.path.basename(args.query), 'results': preds}
print(json.dumps(out, indent=2))
