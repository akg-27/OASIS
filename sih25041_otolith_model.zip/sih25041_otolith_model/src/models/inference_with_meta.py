import argparse
import os
import json
import pandas as pd

# ML imports (only needed if running image mode)
try:
    import torch
    import timm
    import torchvision.transforms as T
    from PIL import Image
except Exception:
    # If user only wants lookup modes, these are not required
    torch = None
    timm = None
    T = None
    Image = None

parser = argparse.ArgumentParser(description="Inference + lookup for otolith project")
parser.add_argument('--model', default='saved_artifacts/model.pt', help='Path to saved model (for image mode)')
parser.add_argument('--image', help='Path to image file (image mode)')
parser.add_argument('--scientific_name', help='Scientific name lookup (text mode)')
parser.add_argument('--locality', help='Locality lookup (text mode)')
parser.add_argument('--metadata_csv', default='data/raw/indobis_otolith_full_details.csv', help='Metadata CSV path')
parser.add_argument('--topk', type=int, default=3, help='Top-K predictions for image mode')
args = parser.parse_args()

# Load metadata CSV (used by all modes)
meta_df = pd.read_csv(args.metadata_csv, dtype=str)
# Normalize index by scientific_name (if duplicates present, keep first)
meta_indexed = meta_df.drop_duplicates(subset=['scientific_name']).set_index('scientific_name')

def lookup_by_scientific(name):
    if name in meta_indexed.index:
        return meta_indexed.loc[name].to_dict()
    return None

def lookup_by_locality(locality):
    # case-insensitive contains match
    matched = meta_df[meta_df['locality'].str.contains(locality, case=False, na=False)]
    results = []
    for _, row in matched.iterrows():
        results.append(row.to_dict())
    return results

def image_mode(image_path, model_path, topk=3):
    if torch is None:
        raise RuntimeError("PyTorch/timm not available in this environment. Install requirements to run image mode.")
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Model not found: {model_path}")
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image not found: {image_path}")

    # load checkpoint
    ckpt = torch.load(model_path, map_location='cpu')
    classes = ckpt.get('classes')
    if classes is None:
        raise RuntimeError("Saved checkpoint does not contain 'classes' key")

    model = timm.create_model('resnet50', pretrained=False, num_classes=len(classes))
    model.load_state_dict(ckpt['model_state'])
    model.eval()

    # transforms
    trans = T.Compose([T.Resize((224,224)), T.ToTensor()])
    img = Image.open(image_path).convert('RGB')
    x = trans(img).unsqueeze(0)

    with torch.no_grad():
        out = model(x)
        probs = torch.softmax(out, dim=1).squeeze().tolist()

    topk_idx = sorted(enumerate(probs), key=lambda ip: -ip[1])[:topk]
    preds = []
    for i, p in topk_idx:
        name = classes[i]
        meta = lookup_by_scientific(name)
        preds.append({
            "scientific_name": name,
            "confidence": float(p),
            "family": meta.get('family','') if meta is not None else '',
            "locality": meta.get('locality','') if meta is not None else '',
            "detail_url": meta.get('detail_url','') if meta is not None else ''
        })
    return {"input_image": os.path.basename(image_path), "predictions": preds}

def scientific_mode(name):
    meta = lookup_by_scientific(name)
    if meta is None:
        return {"query": name, "found": False, "message": "No record found in metadata CSV"}
    return {"query": name, "found": True, "record": meta}

def locality_mode(locality):
    results = lookup_by_locality(locality)
    if not results:
        return {"query": locality, "found": False, "message": "No records found for locality"}
    # condense to unique species with basic fields
    species = {}
    for r in results:
        sp = r.get('scientific_name','')
        if sp not in species:
            species[sp] = {"scientific_name": sp, "family": r.get('family',''), "locality": r.get('locality',''), "detail_url": r.get('detail_url','')}
    return {"query": locality, "found": True, "species": list(species.values())}

# Decide mode (only one should be provided)
modes = [bool(args.image), bool(args.scientific_name), bool(args.locality)]
if sum(modes) != 1:
    print("Error: provide exactly one of --image, --scientific_name, or --locality")
    exit(1)

if args.image:
    out = image_mode(args.image, args.model, topk=args.topk)
elif args.scientific_name:
    out = scientific_mode(args.scientific_name)
else:
    out = locality_mode(args.locality)

print(json.dumps(out, indent=2))
