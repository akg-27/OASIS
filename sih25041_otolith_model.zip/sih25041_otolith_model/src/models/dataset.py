from torch.utils.data import Dataset
from PIL import Image
import pandas as pd
import torchvision.transforms as T
import os

class OtolithDataset(Dataset):
    def __init__(self, csv_path, image_root, transforms=None, mode='train'):
        self.df = pd.read_csv(csv_path)
        self.root = image_root
        self.transforms = transforms or T.Compose([
            T.Resize((256,256)),
            T.RandomResizedCrop(224),
            T.RandomHorizontalFlip(),
            T.ToTensor(),
        ])
        self.classes = sorted(self.df['scientific_name'].dropna().unique())
        self.cls2idx = {c:i for i,c in enumerate(self.classes)}

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        img_path = os.path.join(self.root, row['image'])
        img = Image.open(img_path).convert('RGB')
        x = self.transforms(img)
        y = self.cls2idx.get(row['scientific_name'], -1)
        meta = {'otolithID': row.get('otolithID',''), 'family': row.get('family',''), 'locality': row.get('locality','')}
        return x, y, meta
