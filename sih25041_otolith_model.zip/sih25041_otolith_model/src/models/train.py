import torch, torch.nn as nn, torch.optim as optim
from torch.utils.data import DataLoader
import timm
from src.models.dataset import OtolithDataset
import argparse, os

parser = argparse.ArgumentParser()
parser.add_argument('--train_csv', default='data/processed/train.csv')
parser.add_argument('--val_csv', default='data/processed/val.csv')
parser.add_argument('--img_root', default='data/raw/Otolith_Images')
parser.add_argument('--epochs', type=int, default=12)
parser.add_argument('--batch', type=int, default=8)
parser.add_argument('--out', default='saved_artifacts/model.pt')
parser.add_argument('--lr', type=float, default=3e-4)
parser.add_argument('--num_workers', type=int, default=2)
args = parser.parse_args()

os.makedirs(os.path.dirname(args.out), exist_ok=True)

train_ds = OtolithDataset(args.train_csv, args.img_root)
val_ds   = OtolithDataset(args.val_csv, args.img_root)

train_loader = DataLoader(train_ds, batch_size=args.batch, shuffle=True, num_workers=args.num_workers)
val_loader   = DataLoader(val_ds,   batch_size=args.batch, shuffle=False, num_workers=args.num_workers)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = timm.create_model('resnet50', pretrained=True, num_classes=len(train_ds.classes))
model.to(device)

criterion = nn.CrossEntropyLoss()
optimizer = optim.AdamW(model.parameters(), lr=args.lr)

best_val = 0.0
for epoch in range(args.epochs):
    model.train()
    total, correct = 0,0
    for x,y,_ in train_loader:
        x,y = x.to(device), y.to(device)
        optimizer.zero_grad()
        out = model(x)
        loss = criterion(out, y)
        loss.backward()
        optimizer.step()
        preds = out.argmax(dim=1)
        total += y.size(0); correct += (preds==y).sum().item()
    train_acc = correct/total if total>0 else 0

    model.eval()
    total, correct = 0,0
    with torch.no_grad():
        for x,y,_ in val_loader:
            x,y = x.to(device), y.to(device)
            out = model(x)
            preds = out.argmax(dim=1)
            total += y.size(0); correct += (preds==y).sum().item()
    val_acc = correct/total if total>0 else 0
    print(f"Epoch {epoch+1}/{args.epochs}: train_acc {train_acc:.3f} val_acc {val_acc:.3f}")
    if val_acc > best_val:
        best_val = val_acc
        torch.save({'model_state': model.state_dict(), 'classes': train_ds.classes}, args.out)
        print('Saved best model:', args.out)
