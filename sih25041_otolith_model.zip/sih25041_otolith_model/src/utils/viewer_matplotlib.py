import argparse, json, os
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np

def load_results(json_path):
    with open(json_path, 'r') as f:
        return json.load(f)

def show_images(query_path, matches, topk=5):
    imgs = []
    titles = []

    imgs.append(Image.open(query_path).convert('RGB'))
    titles.append('QUERY\n' + os.path.basename(query_path))

    for m in matches[:topk]:
        img_path = os.path.join('data/raw/Otolith_Images', m['image'])
        if os.path.exists(img_path):
            imgs.append(Image.open(img_path).convert('RGB'))
        else:
            imgs.append(Image.new('RGB', (224,224), (250,250,250)))

        titles.append(
            f"{m.get('scientific_name','')}\nscore:{m.get('score',0):.3f}\n{m.get('family','')}"
        )

    n = len(imgs)
    fig, axes = plt.subplots(1, n, figsize=(4*n, 4))

    if n == 1:
        axes = [axes]

    for ax, img, title in zip(axes, imgs, titles):
        ax.imshow(np.array(img))
        ax.set_title(title, fontsize=10)
        ax.axis('off')

    plt.tight_layout()
    plt.show()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--results', required=True)
    parser.add_argument('--topk', type=int, default=5)
    args = parser.parse_args()

    res = load_results(args.results)
    query_image = res.get('query_image')
    query_path = os.path.join('data/raw/Otolith_Images', query_image)

    matches = res.get('results', [])
    show_images(query_path, matches, topk=args.topk)

if __name__ == '__main__':
    main()
