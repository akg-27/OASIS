# create_embeddings.py
import os, torch, tqdm, pandas as pd
import timm
import torchvision.transforms as T
from PIL import Image
import numpy as np

DATA_CSV = "data/processed/dataset.csv"
IMG_ROOT = "data/raw/Otolith_Images"
OUT_EMB = "data/processed/embeddings.npz"

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

model = timm.create_model("resnet50", pretrained=True)
model.reset_classifier(0)
model = model.to(device)
model.eval()

trans = T.Compose([T.Resize((224,224)), T.ToTensor()])

df = pd.read_csv(DATA_CSV, dtype=str)
embs = []
meta = []

with torch.no_grad():
    for _, row in tqdm.tqdm(df.iterrows(), total=len(df)):
        img_path = os.path.join(IMG_ROOT, row['image'])
        img = Image.open(img_path).convert('RGB')
        x = trans(img).unsqueeze(0).to(device)
        feat = model.forward_features(x)
        feat = torch.nn.functional.adaptive_avg_pool2d(feat, 1).squeeze().cpu().numpy()
        feat = feat / (np.linalg.norm(feat)+1e-10)
        embs.append(feat)
        meta.append({
            'image': row['image'],
            'scientific_name': row.get('scientific_name',''),
            'family': row.get('family',''),
            'detail_url': row.get('detail_url',''),
            'locality': row.get('locality','')
        })

embs = np.vstack(embs).astype('float32')
np.savez_compressed(OUT_EMB, embeddings=embs, meta=meta)
print("Saved embeddings:", OUT_EMB)
