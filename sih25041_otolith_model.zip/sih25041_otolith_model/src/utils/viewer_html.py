import argparse, json, os, html

TEMPLATE = '''
<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>Otolith Retrieval Viewer</title>
  <style>
    body {{ font-family: Arial, sans-serif; padding: 16px; }}
    .row {{ display:flex; gap:16px; align-items:flex-start; margin-bottom:24px; }}
    .card {{ border:1px solid #ddd; padding:8px; width:220px; background:#fafafa; }}
    img {{ width:200px; height:200px; object-fit:contain; background:#fff; display:block; margin:0 auto 8px; }}
    h3 {{ margin:4px 0; font-size:14px; }}
    p {{ margin:4px 0; font-size:13px; color:#333; }}
  </style>
</head>
<body>
  <h1>Otolith Retrieval Viewer</h1>
  <div class="row">
    <div class="card">
      <h3>Query Image</h3>
      <img src="{query_img}" alt="query"/>
      <p><strong>{query_name}</strong></p>
    </div>
  </div>
  <h2>Top Matches</h2>
  <div class="row">
  {cards}
  </div>
</body>
</html>
'''

def make_card(m):
    img = 'data/raw/Otolith_Images/' + m.get('image','')
    safe_name = html.escape(m.get('scientific_name',''))
    safe_family = html.escape(m.get('family',''))
    safe_locality = html.escape(m.get('locality',''))
    safe_url = html.escape(m.get('detail_url',''))
    score = m.get('score',0)
    return f'''
    <div class="card">
      <img src="{img}" onerror="this.style.opacity=0.4"/>
      <h3>{safe_name}</h3>
      <p><strong>Family:</strong> {safe_family}</p>
      <p><strong>Locality:</strong> {safe_locality}</p>
      <p><strong>Score:</strong> {score:.4f}</p>
      <p><a href="{safe_url}" target="_blank">Detail Link</a></p>
    </div>
    '''

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--results', required=True, help='Path to JSON results from inference_retrieval.py')
    parser.add_argument('--out', default='viewer_output.html')
    args = parser.parse_args()

    with open(args.results,'r',encoding='utf-8') as f:
        res = json.load(f)

    query_image = res.get('query_image')
    cards = ''.join([make_card(m) for m in res.get('results', [])])

    html_text = TEMPLATE.format(
        query_img=os.path.join('data/raw/Otolith_Images', query_image),
        query_name=html.escape(query_image),
        cards=cards
    )

    with open(args.out, 'w', encoding='utf-8') as f:
        f.write(html_text)

    print("HTML saved to:", args.out)
    print("Open it by double-clicking the file.")

if __name__ == '__main__':
    main()
