🔧 Installation
1. Install Python

Use Python 3.10 or 3.11
(PyTorch & Pillow will NOT work properly on 3.12+)

2. Create a Virtual Environment
Windows PowerShell:
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt

Linux / macOS:
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

🚀 Run the Project (Full Pipeline)
### STEP 1 — Create the Dataset

Maps each CSV row to its corresponding image.

python src/data/create_dataset_by_order.py

STEP 2 — Generate Dataset Report

View class distribution.

python src/data/dataset_report.py


Report saved at:

data/reports/species_counts.csv

STEP 3 — Generate Image Embeddings (ML Backbone)

This creates embeddings.npz for retrieval.

python src/utils/create_embeddings.py

STEP 4 — Run Retrieval on a Query Image
python src/models/inference_retrieval.py --query data/raw/Otolith_Images/00001.jpg --topk 5 > output.json


Output is formatted JSON containing:

Top matches

Score

Metadata

STEP 5 — Visualize Results
Option A — HTML Viewer (Recommended)

Opens in browser:

python src/utils/viewer_html.py --results output.json --out viewer_output.html


On Windows:

Start-Process viewer_output.html

Option B — GUI Viewer (Matplotlib)
python src/utils/viewer_matplotlib.py --results output.json --topk 5

🧠 How Retrieval Works (Short Explanation)

A pretrained ResNet50 backbone extracts a 2048-dim embedding for each otolith image.

Embeddings are normalized and stored in embeddings.npz.

For a query image, cosine similarity is computed with all reference embeddings.

Top-K matches are returned along with metadata from the CSV.

This approach works perfectly with very small datasets and single image per class.

📦 Training a Classifier (Optional)

If you later collect more images per species, you can train a classifier:

python src/models/train.py --epochs 12 --batch 8 --out saved_artifacts/model.pt


Note: With the current dataset (1 image per species), retrieval performs better.